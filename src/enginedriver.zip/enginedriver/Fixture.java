package enginedriver;

import java.awt.*;

public class Fixture implements IWeightable{
  @Override
  public int getWeight() {
    return 0;
  }

  @Override
  public String getId() {
    return "";
  }

  @Override
  public String getName() {
    return "";
  }

  @Override
  public String getDescription() {
    return "";
  }

  @Override
  public Image getPicture() {
    return null;
  }
}
