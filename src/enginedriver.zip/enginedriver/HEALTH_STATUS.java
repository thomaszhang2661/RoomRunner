package enginedriver;

public enum HEALTH_STATUS {
    SLEEP,
    WOOZY,
    FATIGUED,
    AWAKE
}
