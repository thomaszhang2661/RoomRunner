package enginedriver;

public enum OPERATION {
   North,
  South,
  East,
  West,
  Inventory,
  Look,
  Use,
  Take,
  Drop,
  Examine,
  Answer,
  Save,
  Restore,
}

